package com.remove.duplicate.contacts;


import java.util.List;

public class Presenter {

    ViewInterface view;
    public Presenter(ViewInterface view)
    {
        this.view = view;
    }

    public List<Contact> getAllContacts(){
        return getAllContacts();
    }

    public interface ViewInterface{
        List<Contact> getAllContacts();
    }

}
