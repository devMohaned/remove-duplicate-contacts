package com.remove.duplicate.contacts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;

import java.util.List;

public class MainActivity extends AppCompatActivity implements Presenter.ViewInterface {

    Presenter MVPpresenter = new Presenter(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public List<Contact> getAllContacts() {
        Uri mContactsUri = ContactsContract.Contacts.CONTENT_URI;
        String[] mContactsProjection = {
                ContactsContract.Contacts.LOOKUP_KEY,
                ContactsContract.Contacts.HAS_PHONE_NUMBER,
        };

        String mContactsSelection = null;
        String[] mContactsSelectionArg = null;
        String mContactsSortOrder = null;


        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(mContactsUri,
                mContactsProjection, mContactsSelection, mContactsSelectionArg, mContactsSortOrder);

        if ((cur != null ? cur.getCount() : 0) > 0) {
            while (cur.moveToNext()) {
                String rId = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY));

                if (cur.getInt(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0 /* 1 = True / 0 = False*/) {

                    Uri rSingleContactUri = ContactsContract.Contacts.CONTENT_URI;
                    String[] rSingleContactProjection = {
                            ContactsContract.Contacts.LOOKUP_KEY,
                            ContactsContract.CommonDataKinds.Phone.NUMBER,
                            ContactsContract.Contacts.DISPLAY_NAME,
                    };

                    String rSingleContactSelection = ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY + " = ?";
                    String[] rSingleContactSelectionArg = new String[]{rId};
                    String rSingleContactSortOrder = null;


                    Cursor pCur = cr.query(
                            rSingleContactUri,
                            rSingleContactProjection,
                            rSingleContactSelection,
                            rSingleContactSelectionArg,
                            rSingleContactSortOrder);

                    while (pCur != null && pCur.moveToNext()) {
                        String rName = pCur.getString(pCur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                        String rSinglePhoneNo = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        Contact contact = new Contact();
                        contact.setContactId(rId);
                        contact.setContactName(rName);
                        contact.setContactPhoneNumber(rSinglePhoneNo);
                      /*  Log.i(TAG, "Name: " + rName);
                        Log.i(TAG, "Phone Number: " + rSinglePhoneNo);*/
                    }
                    pCur.close();
                }
            }
        }
        if (cur != null) {
            cur.close();
        }


        return null;
    }
}
